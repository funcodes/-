﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;

namespace 缘分测试3
{
    class from2
    {
    }
}
