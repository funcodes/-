﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.Windows.Forms;

namespace 缘分测试3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //By: Toto
            //totomike@163.com
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            


           
            
            
            }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
            
           
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || richTextBox1.Text == "" || richTextBox2.Text == "" || comboBox1.Text == "" || comboBox2.Text == "")//判别年龄输入框是否为空
                {                                              //
                    MessageBox.Show("亲，你有信息没填哟。");     //
                }                                              // 
                else
                {
                    int AgeScore = 0;

                    int Age1 = Convert.ToInt32(textBox1.Text);
                    int Age2 = Convert.ToInt32(textBox2.Text);
                    if (Age1 > Age2)
                    {
                        AgeScore = (Age1 - Age2) * 11;
                        if (AgeScore > 30) {
                            AgeScore = 30;
                        }

                    }
                    else
                    {
                        AgeScore = (Age2 - Age1) * 11;
                        if (AgeScore > 30)
                        {
                            AgeScore = 30;
                        }
                      //  MessageBox.Show(AgeScore.ToString());
                        if (Age1 == Age2)
                        {
                            AgeScore = 25;
                        }
                    }



                    int NameScore = 0;
                    if (richTextBox1.Text.Length == richTextBox2.Text.Length)
                    {
                        NameScore = 30;
                    }
                    if (richTextBox1.Text.Length > richTextBox2.Text.Length)
                    {
                        NameScore = 20;
                    }
                    if (richTextBox1.Text.Length < richTextBox2.Text.Length)
                    {
                        NameScore = 27;
                    }
                    int StarScore = 0;
                    if (comboBox1.Text == comboBox2.Text)
                    {
                        StarScore = 31;
                    }
                    if (comboBox1.Text == "白羊座")
                    {
                        StarScore = 21;
                        if (comboBox1.Text == "白羊座" && comboBox2.Text == "射手座")
                        {
                            StarScore = 31;
                        }
                        //  MessageBox.Show(StarScore.ToString());
                    }
                    if (comboBox1.Text == "金牛座")
                    {
                        StarScore = 22;
                        if (comboBox1.Text == "金牛座" && comboBox2.Text == "处女座")
                        {
                            StarScore = 31;
                        }
                    }
                    if (comboBox1.Text == "双子座")
                    {
                        StarScore = 19;
                        if (comboBox1.Text == "双子座" && comboBox2.Text == "水瓶座")
                        {
                            StarScore = 32;

                        }
                        if (comboBox1.Text == "双子座" && comboBox2.Text == "天秤座")
                        {
                            StarScore = 33;
                            // MessageBox.Show(StarScore.ToString());
                        }

                    }
                    if (comboBox1.Text == "巨蟹座")
                    {
                        StarScore = 16;
                        if (comboBox1.Text == "巨蟹座" && comboBox2.Text == "双鱼座")
                        {
                            StarScore = 38;
                        }
                        if (comboBox1.Text == "巨蟹座" && comboBox2.Text == "天蝎座")
                        {
                            StarScore = 33;
                        }
                    }
                    if (comboBox1.Text == "狮子座")
                    {
                        StarScore = 23;
                        if (comboBox1.Text == "狮子座" && comboBox2.Text == "白羊座")
                        {
                            StarScore = 34;
                        }
                        if (comboBox1.Text == "狮子座" && comboBox2.Text == "射手座")
                        {
                            StarScore = 31;
                        }
                    }
                    if (comboBox1.Text == "处女座")
                    {
                        StarScore = 20;
                        if (comboBox1.Text == "处女座" && comboBox2.Text == "金牛座")
                        {
                            StarScore = 32;
                        }
                        if (comboBox1.Text == "处女座" && comboBox2.Text == "摩羯座")
                        {
                            StarScore = 32;

                        }
                    }

                    if (comboBox1.Text == "天秤座")
                    {
                        StarScore = 18;
                        if (comboBox1.Text == "天秤座" && comboBox2.Text == "双子座")
                        {
                            StarScore = 36;

                        }
                        if (comboBox1.Text == "天秤座" && comboBox2.Text == "水瓶座")
                        {
                            StarScore = 35;

                        }
                        if (comboBox1.Text == "天秤座" && comboBox2.Text == "处女座")
                        {
                            StarScore = 15;

                        }
                    }
                    if (comboBox1.Text == "天蝎座")
                    {
                        StarScore = 28;
                        if (comboBox1.Text == "天蝎座" && comboBox2.Text == "双鱼座")
                        {
                            StarScore = 35;

                        }
                    }
                    if (comboBox1.Text == "射手座")
                    {
                        StarScore = 27;
                        if (comboBox1.Text == "射手座" && comboBox2.Text == "狮子座")
                        {
                            StarScore = 34;

                        }
                    }
                    if (comboBox1.Text == "摩羯座")
                    {
                        StarScore = 24;
                        if (comboBox1.Text == "摩羯座" && comboBox2.Text == "处女座")
                        {
                            StarScore = 37;

                        }
                        if (comboBox1.Text == "摩羯座" && comboBox2.Text == "金牛座")
                        {
                            StarScore = 32;

                        }
                    }
                    if (comboBox1.Text == "水瓶座")
                    {
                        StarScore = 10;
                        if (comboBox1.Text == "水瓶座" && comboBox2.Text == "双子座")
                        {
                            StarScore = 31;

                        }
                        if (comboBox1.Text == "水瓶座" && comboBox2.Text == "天秤座")
                        {
                            StarScore = 37;

                        }
                    }
                    if (comboBox1.Text == "双鱼座")
                    {
                        StarScore = 14;
                        if (comboBox1.Text == "双鱼座" && comboBox2.Text == "天蝎座")
                        {
                            StarScore = 35;

                        }
                    }

                    int AllScore = 0;
                    AllScore = NameScore + StarScore + AgeScore;
                   // MessageBox.Show(AllScore.ToString());
                    //if(richTextBox1.Text=="景旭"||richTextBox1.Text"姚益阳"||richTextBox1=="程春晖")
                    if (richTextBox1.Text == "景旭")
                    {
                        AllScore = 100;
                    }
                    if (richTextBox1.Text == "姚益阳")
                    {
                        AllScore = 100;
                    }
                    if (richTextBox1.Text == "程春晖")
                    {
                        AllScore = 100;
                    }
                    if (richTextBox1.Text == "焦民政" )
                    
                    {
                        AllScore = 100;
                    }
                    if (richTextBox1.Text == "盘经清"||richTextBox1.Text=="朱明杰"||richTextBox1.Text=="孙琳"||richTextBox1.Text=="许星")//||richTextBox1.Text"凯重涛")
                    {
                        AllScore = 100;
                    }
                    if (richTextBox1.Text == "凯重涛")
                    {
                        AllScore = 100;
                    }
                    if (richTextBox1.Text == "洪发浦") {
                        AllScore = 100;
                    }
                    if (AllScore > 100) {
                        AllScore = 100;
                    }
                    label7.Text = "";
                    label7.Text = AllScore.ToString();
                    
                    if (AllScore < 50) {
                        label8.Text = "有缘无份的一对。。。";
                    }
                    if (AllScore >= 50 && AllScore <= 65) {
                        label8.Text = "排斥与吸引的一对";
                    }
                    if (AllScore >65 && AllScore <= 70)
                    {
                        label8.Text = "蛮不错的一对";
                    }
                    if (AllScore > 70 && AllScore < 75) {
                        label8.Text = "非常棒的一对";
                    }
                    if (AllScore >= 75 && AllScore <80)
                    {
                        label8.Text = "理想的的一对！";
                    } if (AllScore >= 80 && AllScore < 85)
                    {
                        label8.Text = "幸福一生的一对！";
                    }
                    if (AllScore >= 85 && AllScore < 90)
                    {
                        label8.Text = "命中注定的一对！";
                    }
                    if (AllScore >=90 && AllScore < 100)
                    {
                        label8.Text = "爱你一辈子！";
                    }
                    if (richTextBox1.Text == "焦民政" && richTextBox2.Text == "徐闻")
                    {
                        richTextBox2.Text = "宾得女";
                        label8.Text = "宾得我爱你！";
                       // label7.Text = "宾得X99";
                    }
                    else
                    {
                        if (richTextBox1.Text == "程春晖" && richTextBox2.Text == "姚益阳")
                        {
                            label8.Text = "为爱出柜！请祝福";
                        }
                        else
                        {
                            if (richTextBox1.Text == "焦民政" && richTextBox2.Text == "宾得女")
                            {
                                label8.Text = "我爱宾得与徐闻";
                                richTextBox2.Text = "徐闻";
                            }
                            else
                            {
                                if (AllScore == 100)
                                {
                                    label8.Text = "天生一对！";

                                    //  MessageBox.Show("在一起吧！！");
                                    //  Application.Run(new Form1());
                                    Form2 f2 = new Form2();
                                    f2.Show();


                                }
                            }
                        }
                    }
                }

            }
            catch {
                MessageBox.Show("亲，请检测是否输入有错误");
            }
        }

       

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }
      /*  private int Sum(string strTemp)
        {
            byte[] bStringValue = Encoding.ASCII.GetBytes(strTemp);
            int nSum = 0;
            foreach (byte bCharValue in bStringValue)
            {
                nSum += (int)bCharValue;
            }
            return nSum;
        }*/

        private void label7_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
            DialogResult dr = MessageBox.Show("同开发者QQ联系吗？", "", messButton);
            if (dr == DialogResult.OK)
            {
                System.Diagnostics.Process.Start("http://wpa.qq.com/msgrd?v=3&uin=1014281072&site=qq&menu=yes");

            }// From3 f3 = new From3();
        }
    }
}
